

'use strict';

const API_BASE = 'http://localhost:5000/api';


const Session = {
  getToken()        { return localStorage.getItem('sv_token'); },
  setToken(token)   { localStorage.setItem('sv_token', token); },
  clearToken()      { localStorage.removeItem('sv_token'); },
  isLoggedIn()      { return !!this.getToken(); },
};

const MFAState = {
  get username()   { return sessionStorage.getItem('sv_mfa_user'); },
  set username(v)  { if(v) sessionStorage.setItem('sv_mfa_user', v);
                     else sessionStorage.removeItem('sv_mfa_user'); },
  get email()      { return sessionStorage.getItem('sv_mfa_email'); },
  set email(v)     { if(v) sessionStorage.setItem('sv_mfa_email', v);
                     else sessionStorage.removeItem('sv_mfa_email'); },
  clear()          { this.username = null; this.email = null; },
};

const ActivityLog = {
  _key: 'sv_activity',
  get()  {
    try { return JSON.parse(sessionStorage.getItem(this._key)) || []; }
    catch { return []; }
  },
  add(msg, colour='blue') {
    const log = this.get();
    log.unshift({ msg, colour, time: new Date().toLocaleTimeString() });
    if (log.length > 20) log.pop();
    sessionStorage.setItem(this._key, JSON.stringify(log));
  },
  clear() { sessionStorage.removeItem(this._key); },
};

async function apiFetch(path, options = {}) {
  const token = Session.getToken();
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  try {
    const res  = await fetch(API_BASE + path, { ...options, headers });
    const data = await res.json();
    return { status: res.status, ...data };
  } catch (err) {
    console.error('[API] Network error:', err);
    return { ok: false, error: 'Cannot connect to server. Is server.py running?' };
  }
}

/* ════════════════════════════════════════════════════════
   AUTH API
════════════════════════════════════════════════════════ */
const API = {

  /* Register a new account */
  async register({ username, email, password, passwordScore, captchaPassed }) {
    return apiFetch('/register', {
      method: 'POST',
      body: JSON.stringify({ username, email, password, passwordScore, captchaPassed }),
    });
  },

  /* Login with username + password */
  async login({ username, password }) {
    return apiFetch('/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
  },

  async sendOTP({ email, purpose }) {
    return apiFetch('/otp/send', {
      method: 'POST',
      body: JSON.stringify({ email, purpose }),
    });
  },

  /* Verify OTP code submitted by user */
  async verifyOTP({ email, code, username }) {
    return apiFetch('/otp/verify', {
      method: 'POST',
      body: JSON.stringify({ email, code, username }),
    });
  },

  /* Enable MFA for a user */
  async enableMFA({ username }) {
    return apiFetch('/mfa/enable', {
      method: 'POST',
      body: JSON.stringify({ username }),
    });
  },

  /* Get current user profile */
  async getUser() {
    return apiFetch('/user');
  },

  /* Get all users (Admin only) */
  async getAdminUsers() {
    return apiFetch('/admin/users');
  },

  /* Delete a user (Admin only) */
  async deleteUser(username) {
    return apiFetch(`/admin/users/${username}`, { method: 'DELETE' });
  },

  /* Change password */
  async changePassword({ oldPassword, newPassword, score }) {
    return apiFetch('/password/change', {
      method: 'POST',
      body: JSON.stringify({ oldPassword, newPassword, score }),
    });
  },

  /* Logout */
  async logout() {
    await apiFetch('/logout', { method: 'POST' });
    Session.clearToken();
    ActivityLog.clear();
    MFAState.clear();
  },

  /* Delete own account */
  async deleteAccount() {
    return apiFetch('/account', { method: 'DELETE' });
  },

  /* Auth guards for pages */
  requireAuth() {
    // Only redirect if we are NOT already on login page
    if (!Session.isLoggedIn()) {
      if (!window.location.pathname.endsWith('login.html')) {
        window.location.href = 'login.html';
      }
      return false;
    }
    return true;
  },
  requireGuest() {
    // Only redirect if we are NOT already on dashboard
    if (Session.isLoggedIn() && !window.location.pathname.endsWith('dashboard.html')) {
      window.location.href = 'dashboard.html';
    }
  },
};
