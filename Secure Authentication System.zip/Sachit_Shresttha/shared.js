'use strict';


const COMMON_PASSWORDS = new Set([
  'password','password1','123456','12345678','qwerty','abc123','letmein',
  'monkey','1234567890','111111','iloveyou','admin','welcome','login',
  'passw0rd','master','hello','dragon','shadow','000000','superman',
  'batman','football','baseball','soccer','starwars','trustno1'
]);

/* ── Security policy constants ── */
const OTP_VALIDITY_MS       = 10 * 60 * 1000;  // OTP expires after 10 minutes
const MAX_LOGIN_ATTEMPTS    = 5;                 // Lockout after 5 failed attempts
const LOCKOUT_MS            = 5 * 60 * 1000;    // 5-minute lockout duration
const PASSWORD_EXPIRY_DAYS  = 90;               // Warn after 90 days (NIST recommendation)
const PASSWORD_HISTORY_SIZE = 5;                // Block reuse of last 5 passwords


function loadDB() {
  try {
    const raw = localStorage.getItem('sv_db');
    return raw ? JSON.parse(raw) : { users: {}, sessions: {}, pendingOTPs: {}, loginAttempts: {} };
  } catch { return { users: {}, sessions: {}, pendingOTPs: {}, loginAttempts: {} }; }
}
function saveDB() {
  try { localStorage.setItem('sv_db', JSON.stringify(DB)); } catch {}
}
function loadState() {
  try {
    const raw = localStorage.getItem('sv_state');
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}
function saveState() {
  try { localStorage.setItem('sv_state', JSON.stringify(State)); } catch {}
}

const DB    = loadDB();
const _st   = loadState();
const State = {
  currentUser:    _st.currentUser    || null,
  sessionToken:   _st.sessionToken   || null,
  mfaPendingUser: _st.mfaPendingUser || null,
  otpExpiry:      _st.otpExpiry      || null,
  regCaptcha:     false,
  activityLog:    _st.activityLog    || [],
};


function initCanvas() {
  const canvas = document.getElementById('bgCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, dots = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
    dots = [];
    const cols = Math.floor(W / 80), rows = Math.floor(H / 80);
    for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
      if (Math.random() > 0.55) continue;
      dots.push({ x: i*80+40+(Math.random()-.5)*30, y: j*80+40+(Math.random()-.5)*30,
                  alpha: Math.random()*0.25+0.05, speed: 0.002+Math.random()*0.003, phase: Math.random()*Math.PI*2 });
    }
  }
  resize();
  window.addEventListener('resize', resize);
  function draw(t) {
    ctx.clearRect(0,0,W,H);
    dots.forEach(d => {
      const a = ((Math.sin(t*d.speed+d.phase)+1)/2)*d.alpha;
      ctx.beginPath(); ctx.arc(d.x,d.y,1.5,0,Math.PI*2);
      ctx.fillStyle = `rgba(59,130,246,${a})`; ctx.fill();
    });
    requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);
}


const UI = {
  toast(msg, type='success') {
    const el=document.getElementById('toast'), icon=document.getElementById('toastIcon'), txt=document.getElementById('toastMsg');
    if (!el) return;
    icon.textContent = type==='success'?'✓':type==='error'?'✕':'ℹ';
    txt.textContent  = msg;
    el.className = `toast ${type}`; el.classList.add('show');
    clearTimeout(UI._t);
    UI._t = setTimeout(()=>el.classList.remove('show'), 3500);
  },
  setError(id, msg) {
    const el = document.getElementById(`err-${id}`);
    if (!el) return;
    el.textContent = msg; el.style.display = msg ? 'block' : 'none';
    el.classList.toggle('show', !!msg);
  },
  clearErrors(...ids) { ids.forEach(id=>this.setError(id,'')); },
  shake(el) { if(!el)return; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); },
  setText(id, val) { const el=document.getElementById(id); if(el) el.textContent=val; },
};

   /*PASSWORD STRENGTH ENGINE */

const Password = {
  analyse(pw) {
    if (!pw) return { score:0, label:'', colour:'', checks:{}, entropy:0 };
    const checks = {
      length:   pw.length>=8,
      upper:    /[A-Z]/.test(pw),
      lower:    /[a-z]/.test(pw),
      number:   /[0-9]/.test(pw),
      special:  /[^A-Za-z0-9]/.test(pw),
      nocommon: !COMMON_PASSWORDS.has(pw.toLowerCase()),
    };
    let raw=0;
    if(pw.length>=8)raw++; if(pw.length>=12)raw++; if(pw.length>=16)raw++;
    if(checks.upper)raw++; if(checks.lower)raw++; if(checks.number)raw++; if(checks.special)raw++;
    // Common passwords hard-capped at score 1 regardless of complexity
    if(!checks.nocommon) raw=Math.min(raw,1);
    // Shannon entropy: H = L * log2(charset_size)
    const cs=(checks.upper?26:0)+(checks.lower?26:0)+(checks.number?10:0)+(checks.special?32:0);
    const entropy=Math.round(pw.length*Math.log2(Math.max(cs,1)));
    // Boost score for high-entropy passwords (>60 bits considered strong)
    if(entropy>60) raw=Math.min(raw+1,7);
    const score=Math.max(1,Math.min(5,Math.ceil(raw/7*5)));
    const labels =['','Very Weak','Weak','Fair','Strong','Very Strong'];
    const colours=['','#ef4444','#f97316','#f59e0b','#84cc16','#10b981'];
    return { score, label:labels[score], colour:colours[score], checks, entropy };
  },

  updateUI(pw, prefix) {
    const r=this.analyse(pw);
    const fill=document.getElementById(`${prefix}-strength-fill`);
    const lbl =document.getElementById(`${prefix}-strength-label`);
    const ent =document.getElementById(`${prefix}-entropy`);
    if(fill){ fill.style.width=pw?`${r.score/5*100}%`:'0%'; fill.style.background=r.colour; }
    if(lbl) { lbl.textContent=r.label; lbl.style.color=r.colour||'var(--text3)'; }
    if(ent) { ent.textContent=pw?`~${r.entropy} bits`:''; }
    const map={ 'rq-len':r.checks.length,'rq-up':r.checks.upper,'rq-low':r.checks.lower,
                'rq-num':r.checks.number,'rq-sym':r.checks.special,'rq-com':r.checks.nocommon };
    Object.entries(map).forEach(([id,met])=>{ const el=document.getElementById(id); if(el)el.classList.toggle('met',met); });
    return r;
  },

  /*  Password history check  */
  async isReused(newPw, historyHashes) {
    if (!historyHashes || historyHashes.length === 0) return false;
    for (const storedHash of historyHashes) {
      const match = await Auth.verifyPassword(newPw, storedHash);
      if (match) return true;
    }
    return false;
  },

  /*  Password expiry check  */
  daysSinceChange(user) {
    const changed = user.passwordChangedAt || user.createdAt;
    return Math.floor((Date.now() - new Date(changed).getTime()) / (1000 * 60 * 60 * 24));
  },

  isExpired(user) {
    return this.daysSinceChange(user) >= PASSWORD_EXPIRY_DAYS;
  },
};

/* 
   EMAILJS CONFIG
  */
const EMAILJS_PUBLIC_KEY  = 'u0wq3YQimslb0Nqed';
const EMAILJS_SERVICE_ID  = 'service_trxvp2f';
const EMAILJS_TEMPLATE_ID = 'template_k5ibkf3';

/* 
   OTP ENGINE
*/
const OTP = {

  generate() {
    const a = new Uint32Array(1);
    crypto.getRandomValues(a);
    return String(100000 + (a[0] % 900000));
  },

  async send(email, purpose) {
    const code   = this.generate();
    const expiry = Date.now() + OTP_VALIDITY_MS;
    // Hash OTP before storing — plaintext OTP never saved to storage
    const { hash: codeHash, salt: codeSalt } = await Auth.hashOTP(code);
    DB.pendingOTPs[email] = { codeHash, codeSalt, expiry, purpose, attempts: 0 };
    saveDB();

    console.group('%c📧 SecureVault OTP', 'color:#3b82f6;font-weight:bold');
    console.log(`To:      ${email}`);
    console.log(`%cCode:    ${code}`, 'color:#10b981;font-size:18px;font-weight:bold');
    console.log(`Expires: ${new Date(expiry).toLocaleTimeString()}`);
    console.log(`Purpose: ${purpose}`);
    console.groupEnd();

    const keysConfigured = (
      EMAILJS_PUBLIC_KEY  !== 'YOUR_EMAILJS_PUBLIC_KEY' &&
      EMAILJS_SERVICE_ID  !== 'YOUR_EMAILJS_SERVICE_ID' &&
      EMAILJS_TEMPLATE_ID !== 'YOUR_EMAILJS_TEMPLATE_ID'
    );

    if (keysConfigured && typeof emailjs !== 'undefined') {
      try {
        await emailjs.send(
          EMAILJS_SERVICE_ID,
          EMAILJS_TEMPLATE_ID,
          {
            to_email: email,
            otp_code: code,
            purpose:  purpose === 'login' ? 'sign in' : 'MFA setup',
            expiry:   new Date(expiry).toLocaleTimeString(),
          },
          EMAILJS_PUBLIC_KEY
        );
        UI.toast(`Verification code sent to ${email}`, 'success');
      } catch (err) {
        console.error('EmailJS error:', err);
        UI.toast(`Email failed — check console (F12) for OTP code`, 'error');
      }
    } else {
      UI.toast(`Demo OTP: ${code}  (check console F12)`, 'info');
    }

    return code;
  },

  /* Verify OTP  */
  async verify(email, submitted) {
    const rec = DB.pendingOTPs[email];
    if (!rec)                    return { ok: false, reason: 'No code found. Request a new one.' };
    if (Date.now() > rec.expiry) return { ok: false, reason: 'Code has expired. Please resend.' };
    if (rec.attempts >= 3)       return { ok: false, reason: 'Too many attempts. Request a new code.' };

    const match = await Auth.verifyOTP(submitted, rec.codeHash, rec.codeSalt);
    if (!match) {
      rec.attempts++;
      saveDB();
      const l = 3 - rec.attempts;
      return { ok: false, reason: `Incorrect code. ${l} attempt${l !== 1 ? 's' : ''} remaining.` };
    }
    delete DB.pendingOTPs[email];
    saveDB();
    return { ok: true };
  },
};

/* ════════════════════════════════════════════════
   HONEYPOT + BEHAVIOURAL CAPTCHA
   ──────────────────────────────────────────────
   Three-layer bot detection:
   1. Honeypot field — hidden input bots often fill
   2. Timing check   — humans take >600ms to fill a form
   3. Interaction    — checks for mouse/keyboard activity
   Used alongside reCAPTCHA v3 for defence in depth.
════════════════════════════════════════════════ */
const Captcha = {
  _loadTime:   Date.now(),
  _mouseMoved: false,
  _keyPressed: false,
  init() {
    document.addEventListener('mousemove',()=>{this._mouseMoved=true;},{once:true});
    document.addEventListener('keydown',  ()=>{this._keyPressed=true;},{once:true});
  },
  isBot(honeypotId) {
    const hp=document.getElementById(honeypotId);
    if(hp&&hp.value.length>0)               {console.warn('Bot: honeypot filled'); return true;}
    if(Date.now()-this._loadTime<600)       {console.warn('Bot: too fast');        return true;}
    if(!this._mouseMoved&&!this._keyPressed){console.warn('Bot: no interaction'); return true;}
    return false;
  },
  handleClick(boxId, honeypotId, onDone, onBot) {
    const box=document.getElementById(boxId);
    if(!box||box.classList.contains('verified')) return;
    if(this.isBot(honeypotId)) {
      box.style.borderColor='var(--red)';
      UI.toast('Bot behaviour detected — blocked.','error');
      if(onBot)onBot(); return;
    }
    box.classList.add('checking');
    setTimeout(()=>{
      box.classList.remove('checking'); box.classList.add('verified');
      box.setAttribute('aria-checked','true');
      if(onDone)onDone();
    }, 700+Math.random()*500);
  },
};


const Auth = {

  /* Hash a password using PBKDF2-SHA256.
     */
  async hashPassword(pw) {
    const enc       = new TextEncoder();
    const saltBytes = crypto.getRandomValues(new Uint8Array(16));
    const keyMat    = await crypto.subtle.importKey(
      'raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']
    );
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', hash: 'SHA-256', salt: saltBytes, iterations: 600000 },
      keyMat, 256
    );
    const toHex = b => Array.from(b, x => x.toString(16).padStart(2,'0')).join('');
    console.log('[PBKDF2-SHA256] Password hashed — iterations: 600,000');
    return toHex(saltBytes) + ':' + toHex(new Uint8Array(bits));
  },


  async verifyPassword(plaintext, storedHash) {
    try {
      const [saltHex, hashHex] = storedHash.split(':');
      const saltBytes = new Uint8Array(saltHex.match(/.{2}/g).map(h => parseInt(h, 16)));
      const enc    = new TextEncoder();
      const keyMat = await crypto.subtle.importKey(
        'raw', enc.encode(plaintext), 'PBKDF2', false, ['deriveBits']
      );
      const bits = await crypto.subtle.deriveBits(
        { name: 'PBKDF2', hash: 'SHA-256', salt: saltBytes, iterations: 600000 },
        keyMat, 256
      );
      const derived = Array.from(new Uint8Array(bits), x => x.toString(16).padStart(2,'0')).join('');
      // Constant-time comparison — prevents timing attacks
      if (derived.length !== hashHex.length) return false;
      let diff = 0;
      for (let i = 0; i < derived.length; i++) diff |= derived.charCodeAt(i) ^ hashHex.charCodeAt(i);
      const match = diff === 0;
      console.log('[PBKDF2-SHA256] Password verify —', match ? 'MATCH' : 'NO MATCH');
      return match;
    } catch { return false; }
  },

  /* Hash an OTP code using PBKDF2-SHA512.*/
  async hashOTP(code, saltHex) {
    const enc     = new TextEncoder();
    const keyMat  = await crypto.subtle.importKey(
      'raw', enc.encode(code), 'PBKDF2', false, ['deriveBits']
    );
    const saltBytes = saltHex
      ? new Uint8Array(saltHex.match(/.{2}/g).map(h => parseInt(h, 16)))
      : crypto.getRandomValues(new Uint8Array(16));
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', hash: 'SHA-512', salt: saltBytes, iterations: 600000 },
      keyMat, 256
    );
    const hashHex = Array.from(new Uint8Array(bits), b => b.toString(16).padStart(2,'0')).join('');
    const saltOut = Array.from(saltBytes, b => b.toString(16).padStart(2,'0')).join('');
    console.log('[PBKDF2-SHA512] OTP hashed — iterations: 600,000');
    return { hash: hashHex, salt: saltOut };
  },

  /* Verify an OTP code using constant-time comparison. */
  async verifyOTP(code, storedHash, storedSalt) {
    const { hash } = await this.hashOTP(code, storedSalt);
    if (hash.length !== storedHash.length) return false;
    let diff = 0;
    for (let i = 0; i < hash.length; i++) diff |= hash.charCodeAt(i) ^ storedHash.charCodeAt(i);
    return diff === 0;
  },

  
  _token() {
    const b = new Uint8Array(16);
    crypto.getRandomValues(b);
    return Array.from(b, x => x.toString(16).padStart(2,'0')).join('');
  },

  /* Append entry to user's activity log (max 20 entries) */
  log(msg, colour='blue') {
    State.activityLog.unshift({ msg, colour, time: new Date().toLocaleTimeString() });
    if (State.activityLog.length > 20) State.activityLog.pop();
    saveState();
  },

  isLoggedIn()  { return !!(State.sessionToken && DB.sessions[State.sessionToken]); },
  requireAuth() { if (!this.isLoggedIn()) { window.location.href = 'login.html'; } },
  requireGuest(){ if (this.isLoggedIn())  { window.location.href = 'dashboard.html'; } },
};

/* 
   OTP COUNTDOWN TIMER
 */
let _otpInterval = null;
function startOTPCountdown(expiryTs) {
  stopOTPCountdown();
  State.otpExpiry = expiryTs; saveState();
  _otpInterval = setInterval(()=>{
    const rem=Math.max(0,expiryTs-Date.now());
    const mins=Math.floor(rem/60000), secs=Math.floor((rem%60000)/1000);
    const pct=rem/OTP_VALIDITY_MS*100;
    UI.setText('otp-countdown',`${mins}:${String(secs).padStart(2,'0')}`);
    const fill=document.getElementById('otp-timer-fill');
    if(fill){fill.style.width=`${pct}%`;fill.style.background=pct>40?'var(--accent)':pct>15?'var(--amber)':'var(--red)';}
    if(rem<=0){stopOTPCountdown();UI.setError('otp','Code expired — please resend.');}
  },1000);
}
function stopOTPCountdown() { clearInterval(_otpInterval); _otpInterval=null; }

document.addEventListener('DOMContentLoaded', ()=>{
  initCanvas();
  Captcha.init();
});
