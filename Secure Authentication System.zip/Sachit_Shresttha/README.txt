SecureVault — CET324 Advanced CyberSecurity
Assignment 2 | University of Sunderland | 

------------------------------------------------------------
OVERVIEW
SecureVault is a secure user authentication system developed
for the Advanced CyberSecurity module. It demonstrates key cybersecurity
features such as password protection, CAPTCHA, MFA, and
brute-force prevention.

Technologies Used:
• Frontend: HTML, CSS, JavaScript
• Backend: Python (Flask)
• Database: SQLite

------------------------------------------------------------
HOW TO RUN
Requirements:
• Python 
• Internet connection 

Steps:
1. Open project folder
2. Open terminal
3. Run:
   pip install flask flask-cors
   python server.py

4. Open browser:
   http://localhost:5000/login.html

To stop the server:
Press Ctrl + C

Another Steps
Double-click start.bat in this folder
Wait for "Open: http://localhost:5000/login.html"
Open your browser and go to:
       http://localhost:5000/login.html


------------------------------------------------------------
FIRST TIME USE
1. Go to:
   http://localhost:5000/register.html

2. Register a new account
   First user becomes Admin

3. Enable MFA and enter OTP

4. Login to access dashboard

------------------------------------------------------------
FEATURES
• Password strength checker
• Secure password hashing (PBKDF2)
• Multi-Factor Authentication (OTP)
• Google reCAPTCHA (bot protection)
• Brute-force protection (account lock)
• Session management
• Admin panel (RBAC)

------------------------------------------------------------
NOTES
• Do not open HTML files directly
• Always run using Flask server
• Database is created automatically

------------------------------------------------------------
LIMITATIONS
• No HTTPS (localhost only)
• SQLite used for demo purposes
• EmailJS has limited free usage

