from flask import Flask, request, jsonify, send_from_directory, session
from flask_cors import CORS
import sqlite3, hashlib, hmac, os, secrets, time, json
from datetime import datetime, timedelta

app = Flask(__name__, static_folder='.', static_url_path='')
app.secret_key = secrets.token_hex(32)  
CORS(app, supports_credentials=True)

# Database configuration 
DB_PATH             = 'securevault.db'
MAX_LOGIN_ATTEMPTS  = 5
LOCKOUT_SECONDS     = 300          # 5 minutes
OTP_VALIDITY_SECS   = 600          # 10 minutes
PASSWORD_EXPIRY_DAYS= 90
PASSWORD_HISTORY    = 5            # Block last N passwords


#  DATABASE SETUP

def get_db():
    """Get a database connection with row_factory for dict-like access."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create all tables if they don't exist."""
    conn = get_db()
    c = conn.cursor()

    # Users table — stores account info and security metadata
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        username            TEXT PRIMARY KEY,
        email               TEXT NOT NULL UNIQUE,
        password_hash       TEXT NOT NULL,
        password_score      INTEGER DEFAULT 0,
        password_changed_at TEXT,
        role                TEXT DEFAULT 'user',
        mfa_enabled         INTEGER DEFAULT 0,
        email_verified      INTEGER DEFAULT 0,
        captcha_passed      INTEGER DEFAULT 0,
        created_at          TEXT NOT NULL,
        last_login          TEXT
    )''')

    # Password history
    c.execute('''CREATE TABLE IF NOT EXISTS password_history (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        username    TEXT NOT NULL,
        hash        TEXT NOT NULL,
        changed_at  TEXT NOT NULL,
        FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
    )''')

    # Sessions 
    c.execute('''CREATE TABLE IF NOT EXISTS sessions (
        token       TEXT PRIMARY KEY,
        username    TEXT NOT NULL,
        created_at  TEXT NOT NULL,
        expires_at  TEXT NOT NULL,
        FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
    )''')

    # OTP codes — hashed before storage, cleared after use
    c.execute('''CREATE TABLE IF NOT EXISTS pending_otps (
        email       TEXT PRIMARY KEY,
        code_hash   TEXT NOT NULL,
        code_salt   TEXT NOT NULL,
        expires_at  TEXT NOT NULL,
        purpose     TEXT NOT NULL,
        attempts    INTEGER DEFAULT 0
    )''')

    # Login attempts — for brute-force protection
    c.execute('''CREATE TABLE IF NOT EXISTS login_attempts (
        username    TEXT PRIMARY KEY,
        count       INTEGER DEFAULT 0,
        locked_until TEXT
    )''')

    conn.commit()
    conn.close()
    print('[DB] Database initialised:', DB_PATH)


#  CRYPTOGRAPHIC HELPERS
#  Server-side hashing uses PBKDF2-HMAC-SHA256 (Python's
#  hashlib) 
def hash_password(password: str) -> str:
    """
    Hash a password using PBKDF2-HMAC-SHA256.
    600,000 iterations matches NIST SP 800-132 recommendation.
    Returns 'saltHex:hashHex' string.
    """
    salt = os.urandom(16)
    dk   = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 600_000)
    return salt.hex() + ':' + dk.hex()


def verify_password(password: str, stored: str) -> bool:
    """
    Verify a password against a stored PBKDF2 hash.
    Uses hmac.compare_digest for constant-time comparison
    to prevent timing attacks.
    """
    try:
        salt_hex, hash_hex = stored.split(':')
        salt = bytes.fromhex(salt_hex)
        dk   = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 600_000)
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


def hash_otp(code: str) -> tuple[str, str]:
    """
    Hash a 6-digit OTP using PBKDF2-HMAC-SHA512.
    Different algorithm from passwords (defence in depth).
    Returns (hash_hex, salt_hex).
    """
    salt = os.urandom(16)
    dk   = hashlib.pbkdf2_hmac('sha512', code.encode(), salt, 600_000)
    return dk.hex(), salt.hex()


def verify_otp_hash(code: str, stored_hash: str, stored_salt: str) -> bool:
    """Verify OTP code against stored hash using constant-time comparison."""
    salt = bytes.fromhex(stored_salt)
    dk   = hashlib.pbkdf2_hmac('sha512', code.encode(), salt, 600_000)
    return hmac.compare_digest(dk.hex(), stored_hash)


def generate_token() -> str:
    """Generate a 128-bit cryptographically secure session token."""
    return secrets.token_hex(16)


def generate_otp() -> str:
    """Generate a cryptographically secure 6-digit OTP."""
    return str(secrets.randbelow(900000) + 100000)


#  SESSION HELPERS
def get_session_user(token: str):
    """Look up a session token and return the username if valid."""
    if not token:
        return None
    conn = get_db()
    row  = conn.execute(
        'SELECT username, expires_at FROM sessions WHERE token=?', (token,)
    ).fetchone()
    conn.close()
    if not row:
        return None
    if datetime.fromisoformat(row['expires_at']) < datetime.utcnow():
        return None   # Session expired
    return row['username']


def require_auth():
    """Return username from Authorization header, or None if not authenticated."""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    return get_session_user(token)


#  STATIC FILE SERVING
@app.route('/')
def index():
    return send_from_directory('.', 'login.html')


@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory('.', filename)


#  API ROUTES

@app.route('/api/register', methods=['POST'])
def api_register():
    """
    Register a new user account.
    - Validates input
    - Hashes password with PBKDF2-SHA256
    - First user gets Admin role
    - Stores hashed password (never plaintext)
    """
    data     = request.get_json()
    username = (data.get('username') or '').strip()
    email    = (data.get('email')    or '').strip().lower()
    password = data.get('password') or ''
    score    = int(data.get('passwordScore', 0))
    captcha  = bool(data.get('captchaPassed', False))

    if not username or not email or not password:
        return jsonify({'ok': False, 'error': 'All fields required'}), 400

    conn = get_db()
    try:
        # Check username not taken
        if conn.execute('SELECT 1 FROM users WHERE username=?', (username,)).fetchone():
            return jsonify({'ok': False, 'error': 'Username already taken'}), 409

        # Check email not taken
        if conn.execute('SELECT 1 FROM users WHERE email=?', (email,)).fetchone():
            return jsonify({'ok': False, 'error': 'Email already registered'}), 409

        # First registered user becomes Admin
        user_count = conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]
        role = 'admin' if user_count == 0 else 'user'

        pw_hash = hash_password(password)
        now     = datetime.utcnow().isoformat()

        conn.execute('''INSERT INTO users
            (username, email, password_hash, password_score, password_changed_at,
             role, mfa_enabled, email_verified, captcha_passed, created_at)
            VALUES (?,?,?,?,?,?,0,0,?,?)''',
            (username, email, pw_hash, score, now, role, 1 if captcha else 0, now)
        )
        conn.commit()
        print(f'[REGISTER] New user: {username} ({role})')
        return jsonify({'ok': True, 'role': role})

    except Exception as e:
        print(f'[REGISTER ERROR] {e}')
        return jsonify({'ok': False, 'error': 'Registration failed'}), 500
    finally:
        conn.close()


#  POST /api/login 
@app.route('/api/login', methods=['POST'])
def api_login():
    """
    Authenticate a user.
    - Checks lockout status first
    - Verifies password using PBKDF2 constant-time comparison
    - Increments attempt counter on failure
    - Triggers lockout after MAX_LOGIN_ATTEMPTS
    """
    data     = request.get_json()
    username = (data.get('username') or '').strip()
    password = data.get('password') or ''

    if not username or not password:
        return jsonify({'ok': False, 'error': 'Username and password required'}), 400

    conn = get_db()
    try:
        # Check lockout
        attempt_row = conn.execute(
            'SELECT count, locked_until FROM login_attempts WHERE username=?', (username,)
        ).fetchone()

        if attempt_row and attempt_row['locked_until']:
            locked_until = datetime.fromisoformat(attempt_row['locked_until'])
            if datetime.utcnow() < locked_until:
                secs_left = int((locked_until - datetime.utcnow()).total_seconds())
                return jsonify({
                    'ok': False,
                    'locked': True,
                    'secondsLeft': secs_left,
                    'error': f'Account locked. Try again in {secs_left // 60}m {secs_left % 60}s.'
                }), 429

        # Fetch user
        user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()

        # Verify password (always run even if user not found — prevents username enumeration)
        dummy_hash = 'a' * 32 + ':' + 'b' * 32
        pw_ok = verify_password(password, user['password_hash'] if user else dummy_hash)

        if not user or not pw_ok:
            # Increment failed attempts
            count = (attempt_row['count'] if attempt_row else 0) + 1
            locked_until = None
            if count >= MAX_LOGIN_ATTEMPTS:
                locked_until = (datetime.utcnow() + timedelta(seconds=LOCKOUT_SECONDS)).isoformat()
                count = 0

            conn.execute('''INSERT INTO login_attempts (username, count, locked_until)
                VALUES (?,?,?) ON CONFLICT(username) DO UPDATE SET count=?, locked_until=?''',
                (username, count, locked_until, count, locked_until)
            )
            conn.commit()

            left = MAX_LOGIN_ATTEMPTS - count if not locked_until else 0
            if locked_until:
                return jsonify({'ok': False, 'locked': True, 'secondsLeft': LOCKOUT_SECONDS,
                                'error': 'Too many attempts. Account locked for 5 minutes.'}), 429
            return jsonify({'ok': False,
                'attemptsUsed': count,
                'attemptsLeft': left,
                'error': f'Invalid credentials. {left} attempt{"s" if left!=1 else ""} remaining.'}), 401

        # Success — reset attempt counter
        conn.execute('''INSERT INTO login_attempts (username, count, locked_until)
            VALUES (?,0,NULL) ON CONFLICT(username) DO UPDATE SET count=0, locked_until=NULL''',
            (username,)
        )
        conn.commit()

        print(f'[LOGIN] Success: {username}')
        return jsonify({
            'ok':         True,
            'mfaEnabled': bool(user['mfa_enabled']),
            'email':      user['email'],
            'role':       user['role'],
        })

    except Exception as e:
        print(f'[LOGIN ERROR] {e}')
        return jsonify({'ok': False, 'error': 'Login failed'}), 500
    finally:
        conn.close()


@app.route('/api/otp/send', methods=['POST'])
def api_otp_send():
    """
    Generate and store a hashed OTP for a user.
    The actual email sending still uses EmailJS on the frontend
    (no SMTP server needed for this prototype).
    Returns the OTP code so frontend can send it via EmailJS.
    """
    data    = request.get_json()
    email   = (data.get('email') or '').strip().lower()
    purpose = data.get('purpose') or 'login'

    if not email:
        return jsonify({'ok': False, 'error': 'Email required'}), 400

    # Generate secure OTP
    code     = generate_otp()
    expires  = (datetime.utcnow() + timedelta(seconds=OTP_VALIDITY_SECS)).isoformat()
    code_hash, code_salt = hash_otp(code)

    conn = get_db()
    try:
        conn.execute('''INSERT INTO pending_otps (email, code_hash, code_salt, expires_at, purpose, attempts)
            VALUES (?,?,?,?,?,0)
            ON CONFLICT(email) DO UPDATE SET
                code_hash=?, code_salt=?, expires_at=?, purpose=?, attempts=0''',
            (email, code_hash, code_salt, expires, purpose,
             code_hash, code_salt, expires, purpose)
        )
        conn.commit()
        print(f'[OTP] Code for {email}: {code} (expires {expires})')
        # Return code to frontend so EmailJS can send it
        return jsonify({'ok': True, 'code': code, 'expiry': expires})
    except Exception as e:
        print(f'[OTP SEND ERROR] {e}')
        return jsonify({'ok': False, 'error': 'Failed to generate OTP'}), 500
    finally:
        conn.close()


@app.route('/api/otp/verify', methods=['POST'])
def api_otp_verify():
    """
    Verify a submitted OTP code.
    - Checks expiry
    - Limits to 3 attempts per code
    - Uses constant-time comparison
    - Creates session on success
    """
    data     = request.get_json()
    email    = (data.get('email') or '').strip().lower()
    code     = (data.get('code')  or '').strip()
    username = (data.get('username') or '').strip()

    conn = get_db()
    try:
        rec = conn.execute(
            'SELECT * FROM pending_otps WHERE email=?', (email,)
        ).fetchone()

        if not rec:
            return jsonify({'ok': False, 'error': 'No code found. Request a new one.'}), 400

        if datetime.fromisoformat(rec['expires_at']) < datetime.utcnow():
            conn.execute('DELETE FROM pending_otps WHERE email=?', (email,))
            conn.commit()
            return jsonify({'ok': False, 'error': 'Code has expired. Please resend.'}), 400

        if rec['attempts'] >= 3:
            return jsonify({'ok': False, 'error': 'Too many attempts. Request a new code.'}), 429

        if not verify_otp_hash(code, rec['code_hash'], rec['code_salt']):
            conn.execute('UPDATE pending_otps SET attempts=attempts+1 WHERE email=?', (email,))
            conn.commit()
            left = 3 - rec['attempts'] - 1
            return jsonify({'ok': False,
                'error': f'Incorrect code. {left} attempt{"s" if left!=1 else ""} remaining.'}), 401

        # OTP verified — clean up and create session
        conn.execute('DELETE FROM pending_otps WHERE email=?', (email,))

        # Mark email as verified and update last login
        now = datetime.utcnow().isoformat()
        conn.execute(
            'UPDATE users SET email_verified=1, last_login=? WHERE username=?',
            (now, username)
        )

        # Create session token (24-hour expiry)
        token      = generate_token()
        expires_at = (datetime.utcnow() + timedelta(hours=24)).isoformat()
        conn.execute(
            'INSERT INTO sessions (token, username, created_at, expires_at) VALUES (?,?,?,?)',
            (token, username, now, expires_at)
        )
        conn.commit()
        print(f'[OTP VERIFY] Success for {username}')
        return jsonify({'ok': True, 'token': token})

    except Exception as e:
        print(f'[OTP VERIFY ERROR] {e}')
        return jsonify({'ok': False, 'error': 'Verification failed'}), 500
    finally:
        conn.close()


#  POST /api/mfa/enable 
@app.route('/api/mfa/enable', methods=['POST'])
def api_mfa_enable():
    """Enable MFA for a user account."""
    data     = request.get_json()
    username = data.get('username')
    conn = get_db()
    try:
        conn.execute('UPDATE users SET mfa_enabled=1 WHERE username=?', (username,))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


#  GET /api/user 
@app.route('/api/user', methods=['GET'])
def api_get_user():
    """Get current user's profile data (requires valid session token)."""
    username = require_auth()
    if not username:
        return jsonify({'ok': False, 'error': 'Not authenticated'}), 401

    conn = get_db()
    try:
        user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        if not user:
            return jsonify({'ok': False, 'error': 'User not found'}), 404

        days_since = 0
        if user['password_changed_at']:
            delta = datetime.utcnow() - datetime.fromisoformat(user['password_changed_at'])
            days_since = delta.days

        return jsonify({
            'ok': True,
            'user': {
                'username':          user['username'],
                'email':             user['email'],
                'role':              user['role'],
                'mfaEnabled':        bool(user['mfa_enabled']),
                'emailVerified':     bool(user['email_verified']),
                'captchaPassed':     bool(user['captcha_passed']),
                'passwordScore':     user['password_score'],
                'createdAt':         user['created_at'],
                'lastLogin':         user['last_login'],
                'passwordExpired':   days_since >= PASSWORD_EXPIRY_DAYS,
                'passwordAgeDays':   days_since,
            }
        })
    finally:
        conn.close()


#  GET /api/admin/users 
@app.route('/api/admin/users', methods=['GET'])
def api_admin_users():
    """Get all users — Admin only."""
    username = require_auth()
    if not username:
        return jsonify({'ok': False, 'error': 'Not authenticated'}), 401

    conn = get_db()
    try:
        user = conn.execute('SELECT role FROM users WHERE username=?', (username,)).fetchone()
        if not user or user['role'] != 'admin':
            return jsonify({'ok': False, 'error': 'Admin access required'}), 403

        users = conn.execute(
            'SELECT username, email, role, mfa_enabled, email_verified, created_at, last_login FROM users'
        ).fetchall()

        return jsonify({'ok': True, 'users': [dict(u) for u in users]})
    finally:
        conn.close()


#  DELETE /api/admin/users/<username> 
@app.route('/api/admin/users/<target>', methods=['DELETE'])
def api_admin_delete_user(target):
    """Delete a user account — Admin only."""
    username = require_auth()
    if not username:
        return jsonify({'ok': False, 'error': 'Not authenticated'}), 401

    if username == target:
        return jsonify({'ok': False, 'error': 'Cannot delete your own account'}), 400

    conn = get_db()
    try:
        user = conn.execute('SELECT role FROM users WHERE username=?', (username,)).fetchone()
        if not user or user['role'] != 'admin':
            return jsonify({'ok': False, 'error': 'Admin access required'}), 403

        conn.execute('DELETE FROM users WHERE username=?', (target,))
        conn.commit()
        print(f'[ADMIN] {username} deleted user: {target}')
        return jsonify({'ok': True})
    finally:
        conn.close()


#  POST /api/password/change 
@app.route('/api/password/change', methods=['POST'])
def api_change_password():
    """
    Change user password.
    - Verifies current password
    - Checks history (last PASSWORD_HISTORY passwords)
    - Hashes new password
    - Updates history table
    """
    username = require_auth()
    if not username:
        return jsonify({'ok': False, 'error': 'Not authenticated'}), 401

    data    = request.get_json()
    old_pw  = data.get('oldPassword') or ''
    new_pw  = data.get('newPassword') or ''
    score   = int(data.get('score', 0))

    conn = get_db()
    try:
        user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()

        # Verify current password
        if not verify_password(old_pw, user['password_hash']):
            return jsonify({'ok': False, 'error': 'Current password is incorrect'}), 401

        # Check password history
        history = conn.execute(
            'SELECT hash FROM password_history WHERE username=? ORDER BY changed_at DESC LIMIT ?',
            (username, PASSWORD_HISTORY)
        ).fetchall()

        # Also check against current password
        all_hashes = [user['password_hash']] + [h['hash'] for h in history]
        for stored in all_hashes:
            if verify_password(new_pw, stored):
                return jsonify({'ok': False,
                    'error': f'Cannot reuse any of your last {PASSWORD_HISTORY} passwords'}), 400

        # Hash and save new password
        new_hash = hash_password(new_pw)
        now      = datetime.utcnow().isoformat()

        # Save old hash to history
        conn.execute(
            'INSERT INTO password_history (username, hash, changed_at) VALUES (?,?,?)',
            (username, user['password_hash'], now)
        )
        # Keep only last PASSWORD_HISTORY entries
        conn.execute('''DELETE FROM password_history WHERE username=? AND id NOT IN (
            SELECT id FROM password_history WHERE username=? ORDER BY changed_at DESC LIMIT ?)''',
            (username, username, PASSWORD_HISTORY)
        )

        conn.execute(
            'UPDATE users SET password_hash=?, password_score=?, password_changed_at=? WHERE username=?',
            (new_hash, score, now, username)
        )
        conn.commit()
        print(f'[PASSWORD] Changed for {username}')
        return jsonify({'ok': True})

    except Exception as e:
        print(f'[PASSWORD CHANGE ERROR] {e}')
        return jsonify({'ok': False, 'error': 'Password change failed'}), 500
    finally:
        conn.close()


#  POST /api/logout 
@app.route('/api/logout', methods=['POST'])
def api_logout():
    """Invalidate the session token."""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if token:
        conn = get_db()
        conn.execute('DELETE FROM sessions WHERE token=?', (token,))
        conn.commit()
        conn.close()
    return jsonify({'ok': True})


#  DELETE /api/account 
@app.route('/api/account', methods=['DELETE'])
def api_delete_account():
    """Delete the authenticated user's own account."""
    username = require_auth()
    if not username:
        return jsonify({'ok': False, 'error': 'Not authenticated'}), 401

    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn  = get_db()
    try:
        conn.execute('DELETE FROM users WHERE username=?', (username,))
        conn.execute('DELETE FROM sessions WHERE token=?', (token,))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


#  STARTUP
if __name__ == '__main__':
    init_db()
    print('=' * 50)
    print('  SecureVault Backend — CET324')
    print('  Open: http://localhost:5000/login.html')
    print('  Database:', DB_PATH)
    print('=' * 50)
    app.run(debug=True, port=5000)
