@echo off
echo ================================================
echo   SecureVault - CET324 Advanced CyberSecurity
echo ================================================
echo.
echo Installing dependencies...
pip install flask flask-cors
echo.
echo Starting server...
echo Open your browser at: http://localhost:5000/login.html
echo Press Ctrl+C to stop the server.
echo.
python server.py
pause
